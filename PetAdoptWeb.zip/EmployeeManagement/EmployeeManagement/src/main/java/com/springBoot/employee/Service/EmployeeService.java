package com.springBoot.employee.Service;

import com.springBoot.employee.Entity.Employee;

public interface EmployeeService {
	
	Employee createEmployee(Employee employee);
	Employee getEmployeeById(int id);
	Employee updateEmployee(Employee employee);
	void deleteEmployee(int id);

}
