package com.springBoot.employee.ServiceImpl;

public class ManagerServiceImpl {

}
