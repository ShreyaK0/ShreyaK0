package com.springBoot.employee.Service;

public interface ManagerService {

}
