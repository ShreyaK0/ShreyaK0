package com.springBoot.employee.ServiceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springBoot.employee.Entity.Employee;
import com.springBoot.employee.Repository.EmployeeRepo;
import com.springBoot.employee.Service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepo employeeRepo;

	@Override
	public Employee createEmployee(Employee employee) {
		Employee emp = employeeRepo.save(employee);
		return emp;
	}

	@Override
	public Employee getEmployeeById(int id) {
		Optional<Employee> emp = employeeRepo.findById(id);

		if (emp.isPresent()) {
			return emp.get();
		}
		return null;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		Employee existingEmployee = employeeRepo.findById(employee.getEmpId()).get();
		existingEmployee.setEmpName(employee.getEmpName());
		existingEmployee.setAddress(employee.getAddress());
		
		Employee updateEmployee = employeeRepo.save(existingEmployee);
		return updateEmployee;
	}

	@Override
	public void deleteEmployee(int id) {
		employeeRepo.deleteById(id);
	}

}
